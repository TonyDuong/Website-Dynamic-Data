﻿using System.ComponentModel.DataAnnotations;
using System.Web.DynamicData;
using System.Web.UI.WebControls;

public partial class Site : System.Web.UI.MasterPage {

}
